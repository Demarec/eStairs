This dirctory named "eStairs" contains.


One subdirectory:

-ButtonResources


Four files:

-Autodesk.eStairs.Inventor.addin: (4096 bytes)

-eStairs.dll: (2.531.328 bytes)

-Manual e-Stairs.pdf: (1.945.600 bytes)

-ReadMe.txt: (255 bytes)